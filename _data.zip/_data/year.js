module.exports = new Date().getFullYear();
    